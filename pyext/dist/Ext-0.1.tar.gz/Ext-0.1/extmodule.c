#include <Python.h>

static PyObject *ExtError;

static PyObject *
ext_system(PyObject *self, PyObject *args)
{
    const char *command;
    int sts;

    if (!PyArg_ParseTuple(args, "s", &command))
        return NULL;
    sts = system(command);
    if (sts < 0) {
        PyErr_SetString(ExtError, "System command failed");
        return NULL;
    }
    else if (sts > 0) {
        PyErr_SetString(ExtError, "Command failed");
        return NULL;
    }
    return PyLong_FromLong(sts);
    /*return Py_BuildValue("i", sts);*/
}


static PyMethodDef ExtMethods[] = {
    {"system", ext_system, METH_VARARGS,
     "Execute a shell command."},
    {NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC
initext(void)
{
    PyObject *m;

    printf("initexec()\n");
    m = Py_InitModule("ext", ExtMethods);
    if (m == NULL)
        return ;

    ExtError = PyErr_NewException("ext.error", NULL, NULL);
    Py_INCREF(ExtError);
    PyModule_AddObject(m, "error", ExtError);
}

